﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace лаб_5_задание5._2
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y;
            x = 2;
            y = 1;
            int n;
             if (x >= 0)
            {
                 if (y >= 0)
                {
                    
                        if (y > Math.Sqrt(x)) n = 4;
                        else n = 1;


                }
                else n = 2;
            }
            else { if (y >= 0) n = 3;
                  else n = 4;
                 }
            Console.WriteLine(n);
            Console.ReadKey();
        }
    }
}
