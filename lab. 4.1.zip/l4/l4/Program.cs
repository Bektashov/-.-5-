﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l4
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 34;
            int i = -6124;
            double c = -380.08;
            bool l = false;
            string name = "Rasulgonovich";
            Console.WriteLine(" a={0:d}\n i={1:d} \n c={2:f2} \n l= {3:w} \n name={4:w} \n", a, i, c, l, name);
            Console.ReadKey();

        }
    }
}
