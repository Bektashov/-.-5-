﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace лб_5_вар3
{
    class Program
    {
        static void Main(string[] args)
        {
            double max, min,x,y,z,f;
            x = 1;
            y = 2;
            z = 0;
            max = (x>y) ? x : y;
            min = (z > max) ? max : z;
             f = min /( x * x + z);
        
            Console.WriteLine(f);
            Console.ReadKey();
        }
    }
}
